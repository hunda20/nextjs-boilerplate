(function(){
"use strict";
(function(){function ld(s,f){var e=document.createElement("script");e.src=s;e.onerror=f||function(){};document.head.appendChild(e)}
ld("lib/xlsx.full.min.js",function(){ld("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js")})})();
var KEY="sms-data-v1";
var seed={classes:[{id:1,name:"Grade 9A",room:"101"},{id:2,name:"Grade 10B",room:"204"}],
teachers:[{id:1,name:"Almaz Tesfaye",subject:"Mathematics",phone:"0911000001"},{id:2,name:"Dawit Bekele",subject:"Physics",phone:"0911000002"}],
students:[{id:1,name:"Selam Alemu",classId:1,guardian:"Alemu T.",phone:"0922000001"},{id:2,name:"Abel Girma",classId:1,guardian:"Girma H.",phone:"0922000002"},{id:3,name:"Hana Kebede",classId:2,guardian:"Kebede M.",phone:"0922000003"}],
attendance:{},grades:[{id:1,studentId:1,subject:"Mathematics",score:88},{id:2,studentId:2,subject:"Mathematics",score:72},{id:3,studentId:3,subject:"Physics",score:91}],
fees:[{id:1,studentId:1,amount:1500,paid:true},{id:2,studentId:2,amount:1500,paid:false}],tests:[],subs:[],nid:10};
var D;
try{D=JSON.parse(localStorage.getItem(KEY)||"null")}catch(e){D=null}
if(!D||typeof D!="object"||!Array.isArray(D.students))D=JSON.parse(JSON.stringify(seed));
["classes","teachers","students","grades","fees","tests","subs"].forEach(function(k){D[k]=Array.isArray(D[k])?D[k].filter(function(o){return o&&typeof o=="object"}):[]});
if(!D.attendance||typeof D.attendance!="object"||Array.isArray(D.attendance))D.attendance={};
if(!D.tt||typeof D.tt!="object"||Array.isArray(D.tt))D.tt={};
D.nid=Math.max(Number(D.nid)||0,1+Math.max.apply(null,[0].concat(["classes","teachers","students","grades","fees"].reduce(function(a,k){return a.concat(D[k].map(function(o){return Number(o.id)||0}))},[]))));
D.tt=D.tt||{};
if(!Object.keys(D.tt).length){["Mon","Tue","Wed","Thu","Fri"].forEach(function(d,i){D.tt["1|"+d+"|1"]=["Mathematics","English","Physics","Biology","Chemistry"][i];D.tt["1|"+d+"|2"]=["English","Mathematics","Chemistry","Physics","Mathematics"][i]})}
function save(){try{localStorage.setItem(KEY,JSON.stringify(D))}catch(e){}}
function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function $(id){return document.getElementById(id)}
function cls(id){var c=D.classes.find(function(x){return x.id==id});return c?c.name:"—"}
function stu(id){var s=D.students.find(function(x){return x.id==id});return s?s.name:"—"}
var views=["dashboard","students","teachers","classes","attendance","grades","reportcards","timetable","fees","emis","exportres","pwreq","audit","backup","accounts","tests"];
var titles={dashboard:"Dashboard",students:"Students",teachers:"Teachers",classes:"Classes",attendance:"Attendance",grades:"Grades",reportcards:"Report cards",timetable:"Timetable",fees:"Fees",emis:"EMIS",exportres:"Export results",pwreq:"Password requests",audit:"Audit log",backup:"Backup & restore",accounts:"User accounts",tests:"Online tests"};
var S={role:null,user:null,uname:null,child:null},rcStu="",ttClass="";
var ROLE_VIEWS={admin:views.slice(),teacher:["dashboard","students","attendance","grades","reportcards","timetable","exportres","tests"],parent:["reportcards","timetable","fees","tests"],student:["tests","reportcards","timetable"]};
function allowed(){return views.filter(function(v){return ROLE_VIEWS[S.role||"parent"].indexOf(v)>-1})}
function canW(k){return S.role=="admin"||(S.role=="teacher"&&k=="grades")}
function mine(id){return(S.role!="parent"&&S.role!="student")||(S.kids||[]).indexOf(Number(id))>-1}
var q="";var attClass="",attDate=new Date().toISOString().slice(0,10);
function cur(){var h=(location.hash||"").slice(1),a=allowed();return a.indexOf(h)>-1?h:a[0]}
$("nav").onclick=function(e){var v=e.target.getAttribute&&e.target.getAttribute("data-v");if(v){q="";location.hash=v}};
window.addEventListener("hashchange",render);

// generic form dialog
function form(title,fields,vals,onSave){
  var h='<h3 class="fh">'+esc(title)+'</h3>';
  fields.forEach(function(f){
    h+='<label>'+f.l+'</label>';
    if(f.opts){h+='<select name="'+f.k+'">'+f.opts.map(function(o){return '<option value="'+esc(o[0])+'"'+(String(vals[f.k])==String(o[0])?" selected":"")+'>'+esc(o[1])+'</option>'}).join("")+'</select>'}
    else h+='<input name="'+f.k+'" type="'+(f.t||"text")+'" value="'+esc(vals[f.k])+'" maxlength="'+(f.max||120)+'" autocomplete="off"'+(f.t=="number"?' min="0" max="'+(f.k=="score"?100:1000000)+'"':'')+(f.opt?'':' required')+'>';
  });
  h+='<div class="bar fa"><button type="button" id="cx">Cancel</button><button class="p" type="submit">Save</button></div>';
  var fr=$("frm");fr.innerHTML=h;
  $("cx").onclick=function(){$("dlg").close()};
  fr.onsubmit=function(e){e.preventDefault();var o={};fields.forEach(function(f){var v=fr.elements[f.k].value;o[f.k]=f.t=="number"?Number(v):v});onSave(o);save();$("dlg").close();render()};
  $("dlg").showModal();
}
function nid(){return D.nid++}
function classOpts(){return D.classes.map(function(c){return [c.id,c.name]})}
function stuOpts(){return D.students.map(function(s){return [s.id,s.name]})}

// generic table
function table(cols,rows,actions){
  if(!rows.length)return '<div class="card empty">Nothing here yet.</div>';
  return '<div class="wrap"><table><tr>'+cols.map(function(c){return '<th>'+c[0]+'</th>'}).join("")+(actions?'<th></th>':'')+'</tr>'+
  rows.map(function(r){return '<tr>'+cols.map(function(c){return '<td>'+c[1](r)+'</td>'}).join("")+(actions?'<td>'+actions(r)+'</td>':'')+'</tr>'}).join("")+'</table></div>';
}
function acts(kind){return function(r){return '<button data-a="edit" data-k="'+kind+'" data-id="'+r.id+'">Edit</button> <button class="d" data-a="del" data-k="'+kind+'" data-id="'+r.id+'">Delete</button>'}}
function search(){return '<input id="q" placeholder="Search…" value="'+esc(q)+'">'}
function match(o){return !q||JSON.stringify(o).toLowerCase().indexOf(q.toLowerCase())>-1}

var cfg={
 students:{fields:function(){return[{k:"name",l:"Full name"},{k:"classId",l:"Class",opts:classOpts()},{k:"guardian",l:"Guardian"},{k:"phone",l:"Phone"}]},blank:{name:"",classId:"",guardian:"",phone:""}},
 teachers:{fields:function(){return[{k:"name",l:"Full name"},{k:"subject",l:"Subject"},{k:"phone",l:"Phone"}]},blank:{name:"",subject:"",phone:""}},
 classes:{fields:function(){return[{k:"name",l:"Class name"},{k:"room",l:"Room"}]},blank:{name:"",room:""}},
 grades:{fields:function(){return[{k:"studentId",l:"Student",opts:stuOpts()},{k:"subject",l:"Subject"},{k:"score",l:"Score (0–100)",t:"number"}]},blank:{studentId:"",subject:"",score:""}},
 fees:{fields:function(){return[{k:"studentId",l:"Student",opts:stuOpts()},{k:"amount",l:"Amount",t:"number"},{k:"paid",l:"Status",opts:[[true,"Paid"],[false,"Unpaid"]]}]},blank:{studentId:"",amount:"",paid:false}}
};
function openForm(kind,id){
  var c=cfg[kind],item=id?D[kind].find(function(x){return x.id==id}):null;
  if((kind=="students"||kind=="grades"||kind=="fees")&&!(kind=="students"?D.classes:D.students).length){alert(kind=="students"?"Add a class first.":"Add a student first.");return}
  form((item?"Edit ":"Add ")+titles[kind].toLowerCase().replace(/s$/,""),c.fields(),item?item:c.blank,function(o){
    if(kind=="fees")o.paid=String(o.paid)=="true";
    if(kind=="students"||kind=="grades"||kind=="fees"){["classId","studentId"].forEach(function(k){if(k in o)o[k]=Number(o[k])})}
    if(item)Object.assign(item,o);else{o.id=nid();D[kind].push(o)}
  });
}
document.addEventListener("click",function(e){
  var t=e.target,a=t.getAttribute&&t.getAttribute("data-a");if(!a)return;
  var k=t.getAttribute("data-k"),id=t.getAttribute("data-id");
  if(a=="logout")return out();if(a=="pw")return chpw();if(a=="csv")return exp(k);if(a=="xlsx")return exp(k,1);if(a=="imp")return canW(k)?imp(k):0;if(a=="print")return prt();if(a=="rcdl")return rcdl();if(a=="tt")return ttEdit(t);
  if(a=="reset"&&S.role!="admin")return;if((a=="add"||a=="edit"||a=="del"||a=="fee")&&!canW(k||"fees"))return;if(a=="att"&&S.role=="parent")return;if((a=="add"||a=="edit"||a=="del")&&["students","teachers","classes","grades","fees"].indexOf(k)<0)return;
  if(a=="add")openForm(k);
  if(a=="edit")openForm(k,id);
  if(a=="del"&&confirm("Delete this record?")){audit("deleted "+k+" #"+id);
    D[k]=D[k].filter(function(x){return x.id!=id});
    if(k=="classes")D.students.forEach(function(s){if(s.id&&s.classId==id)s.classId=""});
    if(k=="students"){D.grades=D.grades.filter(function(g){return g.studentId!=id});D.fees=D.fees.filter(function(f){return f.studentId!=id})}
    save();render()}
  if(a=="att"){var key=attDate+"|"+attClass;D.attendance[key]=D.attendance[key]||{};D.attendance[key][id]=D.attendance[key][id]=="P"?"A":"P";save();render()}
  if(a=="fee"){var f=D.fees.find(function(x){return x.id==id});f.paid=!f.paid;save();render()}
  if(a=="reset"&&confirm("Reset all data to the sample set?")){audit("reset sample data");D=JSON.parse(JSON.stringify(seed));save();render()}
});

function add(kind,label){return '<div class="bar"><button class="p" data-a="add" data-k="'+kind+'">+ '+label+'</button>'+search()+'<button data-a="xlsx" data-k="'+kind+'">Export Excel</button><button data-a="csv" data-k="'+kind+'">CSV</button>'+(kind=="students"||kind=="teachers"?'<button data-a="imp" data-k="'+kind+'">Import Excel</button>':'')+'</div>'}

 var V={
 dashboard:function(){
  var paid=D.fees.filter(function(f){return f.paid}).reduce(function(a,f){return a+f.amount},0);
  var due=D.fees.filter(function(f){return !f.paid}).reduce(function(a,f){return a+f.amount},0);
  var avg=D.grades.length?Math.round(D.grades.reduce(function(a,g){return a+g.score},0)/D.grades.length):0;
  var st=[["Students",D.students.length],["Teachers",D.teachers.length],["Classes",D.classes.length],["Average score",avg+"%"],["Fees collected",paid.toLocaleString()],["Fees outstanding",due.toLocaleString()]];
  return '<h2>Welcome, '+esc(S.user)+' <span class="tag">'+S.role+'</span></h2><div class="grid">'+st.map(function(s){return '<div class="card stat"><b>'+s[1]+'</b><span>'+s[0]+'</span></div>'}).join("")+'</div>'+
  '<div class="card"><b>Students per class</b>'+D.classes.map(function(c){var n=D.students.filter(function(s){return s.classId==c.id}).length;return '<div class="mt8">'+esc(c.name)+' <span class="tag">'+n+'</span></div>'}).join("")+'</div>'+
  '<p class="mt18"><button data-a="reset">Reset sample data</button></p>';
 },
 students:function(){return '<h2>Students</h2>'+add("students","Add student")+table([["Name",function(r){return esc(r.name)}],["Class",function(r){return esc(cls(r.classId))}],["Guardian",function(r){return esc(r.guardian)}],["Phone",function(r){return esc(r.phone)}]],D.students.filter(match),acts("students"))},
 teachers:function(){return '<h2>Teachers</h2>'+add("teachers","Add teacher")+table([["Name",function(r){return esc(r.name)}],["Subject",function(r){return '<span class="tag">'+esc(r.subject)+'</span>'}],["Phone",function(r){return esc(r.phone)}]],D.teachers.filter(match),acts("teachers"))},
 classes:function(){return '<h2>Classes</h2>'+add("classes","Add class")+table([["Class",function(r){return esc(r.name)}],["Room",function(r){return esc(r.room)}],["Students",function(r){return D.students.filter(function(s){return s.classId==r.id}).length}]],D.classes.filter(match),acts("classes"))},
 attendance:function(){
  if(!attClass&&D.classes.length)attClass=D.classes[0].id;
  var list=D.students.filter(function(s){return s.classId==attClass}),m=D.attendance[attDate+"|"+attClass]||{};
  var p=list.filter(function(s){return m[s.id]=="P"}).length;
  return '<h2>Attendance</h2><div class="bar"><select id="ac">'+D.classes.map(function(c){return '<option value="'+c.id+'"'+(c.id==attClass?" selected":"")+'>'+esc(c.name)+'</option>'}).join("")+'</select><input type="date" id="ad" value="'+esc(attDate)+'"><span class="tag">'+p+' / '+list.length+' present</span></div>'+
  table([["Student",function(r){return esc(r.name)}],["Status",function(r){return m[r.id]=="P"?'<span class="ok">Present</span>':m[r.id]=="A"?'<span class="no">Absent</span>':'—'}]],list,function(r){return '<button data-a="att" data-id="'+r.id+'">Toggle</button>'});
 },
 grades:function(){return '<h2>Grades</h2>'+add("grades","Add grade")+table([["Student",function(r){return esc(stu(r.studentId))}],["Subject",function(r){return esc(r.subject)}],["Score",function(r){return '<span class="'+(r.score>=50?"ok":"no")+'">'+esc(r.score)+'</span>'}]],D.grades.filter(function(g){return match({a:stu(g.studentId),b:g.subject})}),acts("grades"))},
 fees:function(){return '<h2>Fees</h2>'+add("fees","Add fee")+table([["Student",function(r){return esc(stu(r.studentId))}],["Amount",function(r){return Number(r.amount).toLocaleString()}],["Status",function(r){return r.paid?'<span class="ok">Paid</span>':'<span class="no">Unpaid</span>'}]],D.fees.filter(function(f){return mine(f.studentId)&&match({a:stu(f.studentId)})}),function(r){return '<button data-a="fee" data-id="'+r.id+'">Mark '+(r.paid?"unpaid":"paid")+'</button> <button class="d" data-a="del" data-k="fees" data-id="'+r.id+'">Delete</button>'})}
};
function render(){
  if(!S.role||S.must)return;document.body.classList.toggle("ro",!canW(cur()));drawNav();$("main").innerHTML=V[cur()]();
  var qi=$("q");if(qi)qi.oninput=function(){q=qi.value;var p=qi.selectionStart;render();var n=$("q");n.focus();n.setSelectionRange(p,p)};
  var ac=$("ac");if(ac)ac.onchange=function(){attClass=ac.value;render()};
  var tc=$("tc");if(tc)tc.onchange=function(){ttClass=tc.value;render()};var rs=$("rs");if(rs)rs.onchange=function(){rcStu=rs.value;render()};var ad=$("ad");if(ad)ad.onchange=function(){attDate=ad.value||attDate;render()};
}
/* ---- security: PBKDF2 logins, roles, persistent lockout, forced first-login password change, audit log, idle timeout ---- */
var USERS,idle,ITER=310000,LK_KEY="sms-lock-v1",AUD_KEY="sms-audit-v1",DEFS=["Admin#2026","Teach#2026","Parent#2026"];
function hex(b){return Array.from(new Uint8Array(b)).map(function(x){return ("0"+x.toString(16)).slice(-2)}).join("")}
async function hash(pw,salt,it){var s=new Uint8Array((String(salt).match(/../g)||[]).map(function(h){return parseInt(h,16)}));var k=await crypto.subtle.importKey("raw",new TextEncoder().encode(pw),"PBKDF2",false,["deriveBits"]);return hex(await crypto.subtle.deriveBits({name:"PBKDF2",salt:s,iterations:it||150000,hash:"SHA-256"},k,256))}
function rsalt(){return hex(crypto.getRandomValues(new Uint8Array(16)))}
function ceq(a,b){if(typeof a!="string"||typeof b!="string"||a.length!=b.length)return false;var r=0;for(var i=0;i<a.length;i++)r|=a.charCodeAt(i)^b.charCodeAt(i);return r===0}
function putU(){try{localStorage.setItem("sms-users-v1",JSON.stringify(USERS))}catch(e){}}
async function setPass(u,p,must){u.salt=rsalt();u.it=ITER;u.hash=await hash(p,u.salt,ITER);u.must=!!must;putU()}
async function initUsers(){try{USERS=JSON.parse(localStorage.getItem("sms-users-v1")||"null")}catch(e){USERS=null}
 if(USERS&&typeof USERS=="object"&&!Array.isArray(USERS)&&Object.keys(USERS).length)return;
 USERS={};var sd=[["admin","Admin","admin",DEFS[0]],["teacher","Teacher","teacher",DEFS[1]],["parent","Parent","parent",DEFS[2]]];
 for(var i=0;i<3;i++){var s=sd[i];USERS[s[0]]={name:s[1],role:s[2],child:s[2]=="parent"?1:null};await setPass(USERS[s[0]],s[3],true)}}
function lkGet(){try{var o=JSON.parse(localStorage.getItem(LK_KEY)||"{}");return o&&typeof o=="object"&&!Array.isArray(o)?o:{}}catch(e){return{}}}
function lkPut(o){try{localStorage.setItem(LK_KEY,JSON.stringify(o))}catch(e){}}
function audit(ev,who){try{var a=JSON.parse(localStorage.getItem(AUD_KEY)||"[]");if(!Array.isArray(a))a=[];a.push({t:new Date().toISOString().slice(0,19).replace("T"," "),u:String(who||S.uname||"-").slice(0,40),e:String(ev).slice(0,120)});localStorage.setItem(AUD_KEY,JSON.stringify(a.slice(-300)))}catch(e){}}
function bump(){clearTimeout(idle);if(S.uname)idle=setTimeout(idleOut,9e5)}
["click","keydown","touchstart"].forEach(function(e){document.addEventListener(e,bump)});
function idleOut(){audit("session timed out");out()}
function out(){if(S.uname)audit("logout");S={role:null,user:null,uname:null,child:null};clearTimeout(idle);if($("dlg").open)$("dlg").close();$("nav").innerHTML="";loginUI()}
$("dlg").addEventListener("cancel",function(e){if(S.must)e.preventDefault()});
function start(un){var u=USERS[un];if(!u||!ROLE_VIEWS.hasOwnProperty(u.role)){out();return}
 var kids=(Array.isArray(u.kids)?u.kids:(u.child?[u.child]:[])).map(Number);S={uname:un,user:u.name,role:u.role,child:kids[0]||null,kids:kids,must:!!u.must};document.body.classList.remove("out");bump();
 if(S.must){$("main").innerHTML="";$("nav").innerHTML="";$("hu").textContent="";forceChange();return}
 render()}
function pwOK(n,un){return n.length>=10&&/[a-z]/.test(n)&&/[A-Z]/.test(n)&&/\d/.test(n)&&n.toLowerCase().indexOf(String(un).toLowerCase())<0&&DEFS.indexOf(n)<0}
var PWF=[{k:"o",l:"Current password",t:"password"},{k:"n",l:"New password (10+ characters, upper and lower case, a number)",t:"password"},{k:"c",l:"Repeat new password",t:"password"}];
function forceChange(){form("Set a new password to continue",PWF,{o:"",n:"",c:""},function(o){setpw(o.o,o.n,o.c).then(function(ok){if(!ok&&S.must)forceChange()})});$("cx").onclick=out}
function chpw(){form("Change password",PWF,{o:"",n:"",c:""},function(o){setpw(o.o,o.n,o.c)})}
async function setpw(o,n,c){var u=USERS[S.uname];if(!u)return false;
 if(n!==c){alert("The new passwords do not match.");return false}
 if(!pwOK(n,S.uname)){alert("New password needs 10+ characters with upper case, lower case and a number. It cannot be a default password or contain your username.");return false}
 if(!ceq(await hash(o,u.salt,u.it),u.hash)){audit("password change failed");alert("Current password is incorrect.");return false}
 if(o===n){alert("Choose a password different from the current one.");return false}
 await setPass(u,n,false);S.must=false;audit("password changed");alert("Password updated.");render();return true}
function loginUI(){document.body.classList.add("out");$("main").innerHTML='<div class="login card"><h2>🎓 BURAYU ACADAMY</h2><p class="lead">Sign in to continue</p><form id="lf"><label>Username</label><input id="lu" autocomplete="username" maxlength="40" required><label>Password</label><input id="lp" type="password" autocomplete="current-password" maxlength="100" required><p id="le" class="no" role="alert"></p><button class="p" id="lb">Sign in</button></form><p class="ctr"><a href="#" id="fp">Forgot password?</a></p></div>';
 $("fp").onclick=function(e){e.preventDefault();forgot()};
 $("lf").onsubmit=async function(e){e.preventDefault();var le=$("le"),bt=$("lb");
  var un=$("lu").value.trim().toLowerCase().slice(0,40),pw=$("lp").value,known=USERS.hasOwnProperty(un),key=known?un:"_",lk=lkGet(),l=lk[key];
  if(l&&l.until>Date.now()){le.textContent="Too many attempts. Try again in "+Math.ceil((l.until-Date.now())/1000)+" seconds.";return}
  bt.disabled=true;var u=known?USERS[un]:null,ok=false;
  try{if(u)ok=ceq(await hash(pw,u.salt,u.it),u.hash);else await hash(pw,rsalt(),ITER)}catch(x){ok=false}
  bt.disabled=false;
  if(!ok){l=lk[key]=l||{n:0,until:0};l.n++;if(l.n%5==0)l.until=Date.now()+Math.min(30000*Math.pow(2,l.n/5-1),9e5);lkPut(lk);audit(l.until>Date.now()?"login locked":"login failed",un);le.textContent="Invalid username or password.";$("lp").value="";return}
  delete lk[key];lkPut(lk);
  var must=!!u.must||DEFS.indexOf(pw)>-1;if(u.it!==ITER||must!==!!u.must)await setPass(u,pw,must);
  audit("login ok",un);start(un)}}
/* ---- export ---- */
function safe(v){return typeof v=="string"&&/^[=+\-@\t\r]/.test(v)?"'"+v:v}
function cell(v){v=String(v==null?"":v);if(/^[=+\-@\t\r]/.test(v))v="'"+v;return '"'+v.replace(/"/g,'""')+'"'}
function dl(name,text,type){audit("download "+name);var b=new Blob([text],{type:type});
 if(window.AndroidBridge){var fr=new FileReader();fr.onload=function(){AndroidBridge.saveFile(name,type,String(fr.result).split(",")[1]||"")};fr.readAsDataURL(b);return}
 function loc(){var a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1000)}
 if(!window.claude){loc();return}
 claude.use("downloads").then(function(d){if(!d){loc();return}d.save({filename:name,data:b}).catch(function(){})},loc)}
function exp(k,x){if(allowed().indexOf(k)<0)return;var h,r;
 if(k=="students"){h=["Name","Class","Guardian","Phone"];r=D.students.map(function(s){return[s.name,cls(s.classId),s.guardian,s.phone]})}
 else if(k=="teachers"){h=["Name","Subject","Phone"];r=D.teachers.map(function(s){return[s.name,s.subject,s.phone]})}
 else if(k=="classes"){h=["Class","Room"];r=D.classes.map(function(s){return[s.name,s.room]})}
 else if(k=="grades"){h=["Student","Subject","Score"];r=D.grades.map(function(g){return[stu(g.studentId),g.subject,g.score]})}
 else if(k=="fees"){h=["Student","Amount","Status"];r=D.fees.filter(function(f){return mine(f.studentId)}).map(function(f){return[stu(f.studentId),f.amount,f.paid?"Paid":"Unpaid"]})}
 else return;
 if(x)return xl(k,h,r);
 dl(k+".csv","\ufeff"+[h].concat(r).map(function(x){return x.map(cell).join(",")}).join("\r\n"),"text/csv")}
/* ---- report cards ---- */
function ltr(n){return n>=90?"A":n>=80?"B":n>=70?"C":n>=60?"D":n>=50?"E":"F"}
V.reportcards=function(){
 var list=D.students.filter(function(s){return mine(s.id)});
 if(!list.some(function(s){return s.id==rcStu}))rcStu=list.length?list[0].id:"";
 var s=list.find(function(x){return x.id==rcStu});
 if(!s)return '<h2>Report cards</h2><div class="card empty">No students.</div>';
 var g=D.grades.filter(function(x){return x.studentId==s.id}),avg=g.length?Math.round(g.reduce(function(a,x){return a+x.score},0)/g.length):0;
 return '<h2>Report cards</h2><div class="bar noprint">'+(list.length>1?'<select id="rs">'+list.map(function(x){return '<option value="'+x.id+'"'+(x.id==s.id?" selected":"")+'>'+esc(x.name)+'</option>'}).join("")+'</select>':'')+'<button class="p" data-a="print">Print / save as PDF</button><button data-a="rcdl">Download</button></div>'+
 '<div class="card" id="rc"><h3 class="m0">BURAYU ACADAMY – Report Card</h3><p>Student: <b>'+esc(s.name)+'</b> · Class: '+esc(cls(s.classId))+' · '+new Date().toISOString().slice(0,10)+'</p>'+
 table([["Subject",function(r){return esc(r.subject)}],["Score",function(r){return esc(r.score)}],["Grade",function(r){return ltr(r.score)}]],g)+
 '<p><b>Average: '+avg+'%</b> · Grade '+ltr(avg)+' · '+(avg>=50?"Pass":"Needs improvement")+'</p><p class="mt30">Teacher: ____________ &nbsp; Parent: ____________</p></div>'};
function prt(){try{if(window.AndroidBridge){AndroidBridge.print();return}window.print()}catch(e){alert("Printing is unavailable here. Use Download, then print the file.")}}
function rcdl(){dl("report-card.html","<!doctype html><meta charset=utf-8><title>Report card</title><style>body{font:15px system-ui;max-width:700px;margin:30px auto}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:6px;text-align:left}</style>"+$("rc").innerHTML,"text/html")}
/* ---- timetable ---- */
V.timetable=function(){
 var par=S.role=="parent"||S.role=="student",cl=par?(D.students.find(function(s){return s.id==S.child})||{}).classId:(ttClass||(D.classes[0]||{}).id),days=["Mon","Tue","Wed","Thu","Fri"];
 var h='<h2>Timetable</h2>'+(par?'':'<div class="bar"><select id="tc">'+D.classes.map(function(c){return '<option value="'+c.id+'"'+(c.id==cl?" selected":"")+'>'+esc(c.name)+'</option>'}).join("")+'</select>'+(S.role=="admin"?'<span class="tag">Click a cell to edit</span>':'')+'</div>')+'<div class="wrap"><table><tr><th></th>'+days.map(function(d){return '<th>'+d+'</th>'}).join("")+'</tr>';
 for(var p=1;p<=6;p++)h+='<tr><th>P'+p+'</th>'+days.map(function(d){return '<td class="tt" data-a="tt" data-c="'+cl+'" data-d="'+d+'" data-p="'+p+'">'+(esc(D.tt[cl+"|"+d+"|"+p])||"·")+'</td>'}).join("")+'</tr>';
 return h+'</table></div>'};
function ttEdit(t){if(!canW("timetable"))return;var tk=t.getAttribute("data-c")+"|"+t.getAttribute("data-d")+"|"+t.getAttribute("data-p");
 form("Edit period",[{k:"s",l:"Subject (use - to clear)"}],{s:D.tt[tk]||""},function(o){if(o.s.trim()=="-")delete D.tt[tk];else D.tt[tk]=o.s.trim()})}
function xl(k,h,r){if(!window.XLSX){alert("Excel library did not load.");return}var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([h].concat(r).map(function(w){return w.map(safe)})),k);dl(k+".xlsx",XLSX.write(wb,{bookType:"xlsx",type:"array"}),"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
function imp(k){if(!window.XLSX){alert("Excel library did not load.");return}var i=document.createElement("input");i.type="file";i.accept=".xlsx,.xls,.csv";
 i.onchange=function(){var f=i.files[0];if(!f)return;if(f.size>5e6){alert("Choose a file under 5 MB.");return}var fr=new FileReader();
  fr.onload=function(){try{var wb=XLSX.read(fr.result,{type:"array"}),rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:""}),n=0;
   rows.slice(0,2000).forEach(function(o){var nm=String(o.Name||"").trim().slice(0,120);if(!nm)return;
    if(k=="students"){var cn=String(o.Class||"").trim().slice(0,60),c=D.classes.find(function(x){return x.name==cn});if(!c&&cn){c={id:nid(),name:cn,room:""};D.classes.push(c)}D.students.push({id:nid(),name:nm,classId:c?c.id:"",guardian:String(o.Guardian||"").slice(0,120),phone:String(o.Phone||"").slice(0,40)})}
    else D.teachers.push({id:nid(),name:nm,subject:String(o.Subject||"").slice(0,120),phone:String(o.Phone||"").slice(0,40)});n++});
   save();audit("imported "+n+" rows into "+k);render();alert(n+" rows imported.")}catch(e){alert("Could not read that file.")}};fr.readAsArrayBuffer(f)};i.click()}
/* ---- sidebar, EMIS, export results, password resets ---- */
var NAV=[["DASHBOARD",[["dashboard","Dashboard"]]],
["",[["um","User Management",[["students","Manage Students"],["teachers","Manage Teachers"],["accounts","User Accounts"]]]]],
["",[["ac","Academic Setup",[["classes","Classes"],["attendance","Attendance"],["timetable","Timetable"],["fees","Fees"]]]]],
["EMIS MANAGEMENT",[["emis","Student EMIS Information"],["exportres","Download Export Student Results"],["rm","Result Management",[["grades","Enter Results"],["reportcards","Report Cards"]]]]],
["ONLINE TESTS",[["tests","Online Tests"]]],
["SECURITY",[["pwreq","Password Reset Requests"],["audit","Audit Log"],["backup","Backup & Restore"]]],
["ACCOUNT",[["a:pw","Change Password"],["a:logout","Logout"]]]];
var OPEN={um:true,ac:true,rm:true},exClass="",PR;
try{PR=JSON.parse(localStorage.getItem("sms-pwreq-v1")||"[]")}catch(e){PR=[]}if(!Array.isArray(PR))PR=[];
function putR(){PR=PR.slice(-200);try{localStorage.setItem("sms-pwreq-v1",JSON.stringify(PR))}catch(e){}}
function pend(){return PR.filter(function(r){return r.s=="pending"}).length}
function drawNav(){var a=allowed(),c=cur(),h="";
 function link(k){return '<a data-v="'+k[0]+'" class="'+(k[0]==c?"on":"")+'">'+k[1]+(k[0]=="pwreq"&&pend()?' <b class="bd">'+pend()+'</b>':"")+'</a>'}
 NAV.forEach(function(sec){var it=sec[1].map(function(x){
  if(x[2]){var kids=x[2].filter(function(k){return a.indexOf(k[0])>-1});if(!kids.length)return "";var o=OPEN[x[0]];
   return '<a class="gh'+(o?" op":"")+'" data-g="'+x[0]+'">'+x[1]+'<i>'+(o?"▾":"▸")+'</i></a>'+(o?'<div class="sub">'+kids.map(link).join("")+'</div>':"")}
  if(x[0].indexOf("a:")==0)return '<a data-a="'+x[0].slice(2)+'">'+x[1]+'</a>';
  return a.indexOf(x[0])>-1?link(x):""}).join("");
  if(it)h+=(sec[0]?'<small>'+sec[0]+'</small>':"")+it});
 $("nav").innerHTML=h;$("hu").textContent="Welcome, "+S.user}
$("nav").onclick=function(e){var t=e.target.closest("a");if(!t)return;var g=t.getAttribute("data-g"),v=t.getAttribute("data-v");
 if(g){OPEN[g]=!OPEN[g];drawNav();return}if(v){q="";location.hash=v;document.body.classList.remove("nv")}};
$("mb").onclick=function(){document.body.classList.toggle("nv")};
$("nt").onclick=function(){var n=pend(),m=[];if(S.role=="admin"){if(n)m.push(n+" pending password reset request(s).");var lb=lastBk();if(!lb||Date.now()-new Date(lb.replace(" ","T")).getTime()>6048e5)m.push("No backup in the last 7 days. Open Backup & Restore.")}alert(m.length?m.join("\n"):"No new notifications.")};
V.dashboard=function(){
 var paid=D.fees.filter(function(f){return f.paid}).reduce(function(a,f){return a+f.amount},0),due=D.fees.filter(function(f){return !f.paid}).reduce(function(a,f){return a+f.amount},0);
 var avg=D.grades.length?Math.round(D.grades.reduce(function(a,g){return a+g.score},0)/D.grades.length):0;
 var ov=[["👨‍🎓 Students",D.students.length,"Students registered in this school","c1"],["👨‍🏫 Teachers",D.teachers.length,"Teachers assigned to this school","c2"],["🏫 Classes",D.classes.length,"Classes this year","c3"],["📋 Results",D.grades.length,"Result entries recorded","c4"]];
 var st=[["Average score",avg+"%"],["Fees collected",paid.toLocaleString()],["Fees outstanding",due.toLocaleString()],["Password requests",pend()]];
 return '<div class="hero"><h2>🏫 School Admin Dashboard</h2><p>Welcome, '+esc(S.user)+'. Use the sidebar to manage users, academic records, results and EMIS information.</p><div class="chips"><span><b>School:</b> Burayu Acadamy</span><span><b>Role:</b> '+S.role+'</span></div></div>'+
 '<h3 class="sh">📊 School Overview</h3><div class="ov">'+ov.map(function(o){return '<div class="'+o[3]+'"><small>'+o[0]+'</small><b>'+o[1]+'</b><small>'+o[2]+'</small></div>'}).join("")+'</div>'+
 '<h3 class="sh">📚 Summary</h3><div class="grid">'+st.map(function(s){return '<div class="card stat"><b>'+s[1]+'</b><span>'+s[0]+'</span></div>'}).join("")+'</div>'+
 '<div class="card"><b>Students per class</b>'+D.classes.map(function(c){var n=D.students.filter(function(s){return s.classId==c.id}).length;return '<div class="mt8">'+esc(c.name)+' <span class="tag">'+n+'</span></div>'}).join("")+'</div>'+
 (S.role=="admin"?'<p class="mt18"><button data-a="reset">Reset sample data</button></p>':"")};
/* Student EMIS Information */
function emisData(){return {h:["EMIS ID","Student","Gender","Date of birth","Class","Guardian","Status"],r:D.students.map(function(s){return[s.emisId||"",s.name,s.gender||"",s.dob||"",cls(s.classId),s.guardian,s.status||"Active"]})}}
V.emis=function(){
 var rows=D.students.filter(function(s){return match({a:s.name,b:s.emisId,c:cls(s.classId)})});
 return '<h2>Student EMIS Information</h2><div class="bar"><button class="p" data-a="emisauto">Auto-assign missing EMIS IDs</button>'+search()+'<button data-a="emisx" data-k="x">Export Excel</button><button data-a="emisx" data-k="c">CSV</button></div>'+
 table([["EMIS ID",function(r){return r.emisId?esc(r.emisId):'<span class="no">Not assigned</span>'}],["Student",function(r){return esc(r.name)}],["Gender",function(r){return esc(r.gender||"—")}],["Date of birth",function(r){return esc(r.dob||"—")}],["Class",function(r){return esc(cls(r.classId))}],["Guardian",function(r){return esc(r.guardian)}],["Status",function(r){return '<span class="tag">'+esc(r.status||"Active")+'</span>'}]],rows,function(r){return '<button data-a="emis" data-id="'+r.id+'">Edit EMIS</button>'})};
/* Download Export Student Results */
function resData(){var cl=D.students.filter(function(s){return !exClass||s.classId==exClass}),subs=[];
 D.grades.forEach(function(g){if(subs.indexOf(g.subject)<0)subs.push(g.subject)});
 return {h:["EMIS ID","Student","Class"].concat(subs,["Average","Grade","Result"]),r:cl.map(function(s){var g=D.grades.filter(function(x){return x.studentId==s.id}),av=g.length?Math.round(g.reduce(function(a,x){return a+x.score},0)/g.length):"";
  return [s.emisId||"",s.name,cls(s.classId)].concat(subs.map(function(sb){var f=g.find(function(x){return x.subject==sb});return f?f.score:""}),[av,av===""?"":ltr(av),av===""?"":(av>=50?"Pass":"Fail")])})}}
V.exportres=function(){var d=resData();
 return '<h2>Download Export Student Results</h2><div class="bar"><select id="ec"><option value="">All classes</option>'+D.classes.map(function(c){return '<option value="'+c.id+'"'+(c.id==exClass?" selected":"")+'>'+esc(c.name)+'</option>'}).join("")+'</select><button class="p" data-a="exs" data-k="x">Download Excel</button><button data-a="exs" data-k="c">Download CSV</button></div>'+
 table(d.h.map(function(h,i){return [h,function(r){return esc(r[i])}]}),d.r)};
document.addEventListener("change",function(e){if(e.target.id=="ec"){exClass=e.target.value;render()}});
/* Password Reset Requests */
V.pwreq=function(){return '<h2>Password Reset Requests</h2>'+table([["Username",function(r){return esc(r.u)}],["Requested",function(r){return esc(r.d)}],["Status",function(r){return '<span class="'+(r.s=="approved"?"ok":r.s=="rejected"?"no":"tag")+'">'+esc(r.s)+'</span>'}]],PR.slice().reverse(),function(r){return r.s=="pending"?'<button class="p" data-a="pwa" data-id="'+r.id+'">Approve</button> <button class="d" data-a="pwr" data-id="'+r.id+'">Reject</button>':""})+'<p class="mu">Approving sets a temporary password shown once on screen. Share it privately and ask the user to change it after signing in.</p>'};
function tmp(){var c="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789",b=crypto.getRandomValues(new Uint8Array(10)),s="";for(var i=0;i<10;i++)s+=c[b[i]%c.length];return s+"7a"}
function forgot(){form("Request password reset",[{k:"u",l:"Username"}],{u:""},function(o){var u=o.u.trim().toLowerCase();
 if(USERS.hasOwnProperty(u)&&!PR.some(function(r){return r.u==u&&r.s=="pending"})){PR.push({id:Date.now(),u:u,d:new Date().toISOString().slice(0,16).replace("T"," "),s:"pending"});putR();audit("reset requested",u)}
 alert("If that account exists, a reset request has been sent to the school administrator.")})}
document.addEventListener("click",async function(e){var t=e.target,a=t.getAttribute&&t.getAttribute("data-a");if(!a||!S.role)return;var id=t.getAttribute("data-id"),k=t.getAttribute("data-k");
 if(a=="emis"&&S.role=="admin"){var s=D.students.find(function(x){return x.id==id});if(!s)return;
  form("Edit EMIS information",[{k:"emisId",l:"EMIS ID",opt:1},{k:"gender",l:"Gender",opts:[["","—"],["Female","Female"],["Male","Male"]]},{k:"dob",l:"Date of birth",t:"date",opt:1},{k:"status",l:"Status",opts:[["Active","Active"],["Transferred","Transferred"],["Graduated","Graduated"],["Dropped out","Dropped out"]]}],{emisId:s.emisId||"",gender:s.gender||"",dob:s.dob||"",status:s.status||"Active"},function(o){
   o.emisId=o.emisId.trim();if(o.emisId&&D.students.some(function(x){return x.id!=s.id&&x.emisId==o.emisId})){alert("That EMIS ID is already used by another student.");return}Object.assign(s,o)})}
 if(a=="emisauto"&&S.role=="admin"){D.students.forEach(function(s){if(!s.emisId)s.emisId="EMIS-"+("00000"+s.id).slice(-5)});save();render()}
 if(a=="emisx"&&S.role=="admin"){var d=emisData();if(k=="x")xl("student-emis",d.h,d.r);else dl("student-emis.csv","\ufeff"+[d.h].concat(d.r).map(function(x){return x.map(cell).join(",")}).join("\r\n"),"text/csv")}
 if(a=="exs"&&allowed().indexOf("exportres")>-1){var d=resData();if(k=="x")xl("student-results",d.h,d.r);else dl("student-results.csv","\ufeff"+[d.h].concat(d.r).map(function(x){return x.map(cell).join(",")}).join("\r\n"),"text/csv")}
 if((a=="pwa"||a=="pwr")&&S.role=="admin"){var r=PR.find(function(x){return x.id==id});if(!r||r.s!="pending")return;
  if(a=="pwr"||!USERS.hasOwnProperty(r.u)){r.s="rejected";audit("reset rejected for "+r.u)}
  else{var p=tmp(),u=USERS[r.u];await setPass(u,p,true);var lk=lkGet();delete lk[r.u];lkPut(lk);r.s="approved";audit("reset approved for "+r.u);alert("Temporary password for "+r.u+": "+p)}
  putR();render()}});
V.audit=function(){var a=[];try{a=JSON.parse(localStorage.getItem(AUD_KEY)||"[]")}catch(e){}if(!Array.isArray(a))a=[];
 return '<h2>Audit log</h2>'+table([["Time",function(r){return esc(r.t)}],["User",function(r){return esc(r.u)}],["Event",function(r){return esc(r.e)}]],a.slice().reverse())+'<p class="mu">The last 300 security events recorded on this device.</p>'};

/* ---- Backup & Restore (admin only) ---- */
var BK_KEY="sms-lastbackup-v1";
function lastBk(){try{return localStorage.getItem(BK_KEY)||""}catch(e){return""}}
function bkPack(withUsers){var a=[];try{a=JSON.parse(localStorage.getItem(AUD_KEY)||"[]")}catch(e){}if(!Array.isArray(a))a=[];
 var o={app:"school-management-system",version:1,created:new Date().toISOString(),data:D,passwordRequests:PR,audit:a};
 if(withUsers)o.users=USERS;return o}
V.backup=function(){var lb=lastBk();
 return '<h2>Backup &amp; Restore</h2>'+
 '<div class="card"><b>Download a backup</b><p class="mu">Saves students, teachers, classes, grades, fees, timetable, attendance, password reset requests and the audit log into one file. Last backup: <b>'+(lb?esc(lb):"never")+'</b></p>'+
 '<label><input type="checkbox" id="bku" checked> Include user accounts (password hashes, no plain passwords)</label>'+
 '<p><button class="p" data-a="bkdl">Download backup</button></p></div>'+
 '<div class="card mt18"><b>Restore from a backup</b><p class="mu">Replaces ALL current data on this device with the backup file. A safety copy of the current data is downloaded first.</p>'+
 '<p><button class="d" data-a="bkrs">Choose backup file…</button></p></div>'+
 '<p class="mu">Keep backup files private: they contain student records. Data lives in this browser only, so back up regularly and before clearing browser data.</p>'};
function bkOK(o){
 if(!o||typeof o!="object"||o.app!="school-management-system"||!o.data||typeof o.data!="object")return"This is not a valid backup file.";
 var d=o.data;if(["classes","teachers","students","grades","fees"].some(function(k){return!Array.isArray(d[k])}))return"Backup data is incomplete.";
 if(o.passwordRequests&&!Array.isArray(o.passwordRequests))return"Password requests section is damaged.";
 if(o.users){if(typeof o.users!="object"||Array.isArray(o.users))return"User accounts section is damaged.";
  var ks=Object.keys(o.users);if(!ks.length)return"Backup has no user accounts.";
  for(var i=0;i<ks.length;i++){var u=o.users[ks[i]];if(!u||!ROLE_VIEWS.hasOwnProperty(u.role)||typeof u.hash!="string"||!/^[0-9a-f]+$/.test(u.salt||"")||!(u.it>0))return"User account \""+esc(ks[i])+"\" is damaged."}
  if(!ks.some(function(k){return o.users[k].role=="admin"}))return"Backup has no admin account."}
 return"";}
document.addEventListener("click",function(e){var t=e.target,a=t.getAttribute&&t.getAttribute("data-a");if(!a||S.role!="admin")return;
 if(a=="bkdl"){var cb=$("bku"),o=bkPack(!cb||cb.checked);try{localStorage.setItem(BK_KEY,new Date().toISOString().slice(0,16).replace("T"," "))}catch(x){}
  audit("backup downloaded");dl("school-backup-"+new Date().toISOString().slice(0,10)+".json",JSON.stringify(o,null,1),"application/json");render()}
 if(a=="bkrs"){var i=document.createElement("input");i.type="file";i.accept=".json,application/json";
  i.onchange=function(){var f=i.files[0];if(!f)return;if(f.size>5e6){alert("Choose a file under 5 MB.");return}var fr=new FileReader();
   fr.onload=function(){var o;try{o=JSON.parse(fr.result)}catch(x){alert("Could not read that file.");return}
    var er=bkOK(o);if(er){alert(er);return}
    if(!confirm("Restore this backup"+(o.created?" from "+o.created.slice(0,16).replace("T"," "):"")+"? All current data on this device will be replaced."))return;
    dl("safety-copy-before-restore.json",JSON.stringify(bkPack(true),null,1),"application/json");
    D=o.data;["tests","subs"].forEach(function(k){D[k]=Array.isArray(D[k])?D[k]:[]});D.attendance=D.attendance&&typeof D.attendance=="object"&&!Array.isArray(D.attendance)?D.attendance:{};D.tt=D.tt&&typeof D.tt=="object"&&!Array.isArray(D.tt)?D.tt:{};
    D.nid=Math.max(Number(D.nid)||0,1+Math.max.apply(null,[0].concat(["classes","teachers","students","grades","fees"].reduce(function(x,k){return x.concat(D[k].map(function(r){return Number(r&&r.id)||0}))},[]))));
    save();PR=(o.passwordRequests||PR).filter(function(r){return r&&typeof r.u=="string"&&typeof r.s=="string"});putR();
    if(o.users){USERS=o.users;putU();if(!USERS[S.uname]){audit("restore completed");alert("Backup restored. Your account is not in this backup, so you will be signed out.");out();return}}
    try{if(Array.isArray(o.audit))localStorage.setItem(AUD_KEY,JSON.stringify(o.audit.slice(-300)))}catch(x){}
    audit("backup restored");alert("Backup restored.");render()};fr.readAsText(f)};i.click()}});

/* ---- User accounts: teachers, parents, students (admin) ---- */
var RL={admin:"Admin",teacher:"Teacher",parent:"Parent",student:"Student"};
function kidNames(u){return(Array.isArray(u.kids)?u.kids:(u.child?[u.child]:[])).map(function(i){return stu(i)}).join(", ")||"—"}
V.accounts=function(){var ks=Object.keys(USERS);
 return '<h2>User Accounts</h2><div class="bar"><button class="p" data-a="u_add" data-k="teacher">+ Teacher account</button><button class="p" data-a="u_add" data-k="parent">+ Parent account</button><button class="p" data-a="u_add" data-k="student">+ Student account</button></div>'+
 table([["Username",function(r){return esc(r)}],["Name",function(r){return esc(USERS[r].name)}],["Role",function(r){return '<span class="tag">'+RL[USERS[r].role]+'</span>'}],["Linked student(s)",function(r){return USERS[r].role=="parent"||USERS[r].role=="student"?esc(kidNames(USERS[r])):"—"}],["Status",function(r){return USERS[r].must?'<span class="no">Must set password</span>':'<span class="ok">Active</span>'}]],ks,function(r){
  return '<button data-a="u_reset" data-id="'+esc(r)+'">New password</button> '+(USERS[r].role=="parent"?'<button data-a="u_link" data-id="'+esc(r)+'">Link child</button> ':"")+(r!=S.uname?'<button class="d" data-a="u_del" data-id="'+esc(r)+'">Delete</button>':"")})+
 '<p class="mu">A temporary password is shown once when you create an account or set a new password. Give it to the person privately; they must choose their own password at first sign-in.</p>'};
function unameOK(n){return/^[a-z0-9._-]{3,30}$/.test(n)}
document.addEventListener("click",function(e){var t=e.target,a=t.getAttribute&&t.getAttribute("data-a");if(!a||a.indexOf("u_")!=0||S.role!="admin")return;
 var k=t.getAttribute("data-k"),id=t.getAttribute("data-id");
 if(a=="u_add"){var needS=k!="teacher";if(needS&&!D.students.length){alert("Add a student first.");return}
  var f=[{k:"un",l:"Username (letters, numbers . _ -)"},{k:"nm",l:k=="teacher"?"Teacher full name":k=="parent"?"Parent / guardian name":"Student login name"}];
  if(needS)f.push({k:"st",l:k=="parent"?"Child":"Student record",opts:stuOpts()});
  form("New "+RL[k]+" account",f,{un:"",nm:"",st:needS?D.students[0].id:""},function(o){var un=o.un.trim().toLowerCase();
   if(!unameOK(un)){alert("Username must be 3-30 characters: letters, numbers, dot, dash or underscore.");return}
   if(USERS.hasOwnProperty(un)){alert("That username already exists.");return}
   var u={name:o.nm.trim().slice(0,60)||un,role:k,child:null};if(needS){u.kids=[Number(o.st)];u.child=Number(o.st)}
   var p=tmp();USERS[un]=u;setPass(u,p,true).then(function(){audit("created "+k+" account "+un);alert("Account created.\nUsername: "+un+"\nTemporary password: "+p+"\n\nShare it privately. It will not be shown again.");render()})})}
 if(a=="u_reset"&&USERS.hasOwnProperty(id)){if(!confirm("Set a new temporary password for "+id+"?"))return;var p=tmp(),u=USERS[id];
  setPass(u,p,true).then(function(){var lk=lkGet();delete lk[id];lkPut(lk);audit("password reset by admin for "+id);alert("Temporary password for "+id+": "+p+"\nIt will not be shown again.");render()})}
 if(a=="u_link"&&USERS.hasOwnProperty(id)){var u=USERS[id];form("Link another child to "+id,[{k:"st",l:"Child",opts:stuOpts()}],{st:D.students[0]?D.students[0].id:""},function(o){
   u.kids=Array.isArray(u.kids)?u.kids:(u.child?[u.child]:[]);var n=Number(o.st);if(u.kids.indexOf(n)<0)u.kids.push(n);u.child=u.kids[0];putU();audit("linked child "+n+" to "+id)})}
 if(a=="u_del"&&USERS.hasOwnProperty(id)&&id!=S.uname){var admins=Object.keys(USERS).filter(function(x){return USERS[x].role=="admin"});
  if(USERS[id].role=="admin"&&admins.length<2){alert("You cannot delete the last admin.");return}
  if(!confirm("Delete account "+id+"?"))return;delete USERS[id];putU();audit("deleted account "+id);render()}});

/* ---- Online tests ---- */
var TV={m:"list",id:null},TK=null;
function myT(id){var t=D.tests.find(function(x){return x.id==id});return t&&(S.role=="admin"||t.by==S.uname)?t:null}
function tsubs(id){return D.subs.filter(function(x){return x.testId==id})}
function pct(s){return s.total?Math.round(100*s.score/s.total):0}
function finalize(sub){var t=D.tests.find(function(x){return x.id==sub.testId});if(!t||sub.end)return;
 var sc=0;t.qs.forEach(function(q,i){if(sub.ans&&sub.ans[i]===q.c)sc++});sub.score=sc;sub.total=t.qs.length;sub.end=new Date().toISOString().slice(0,16).replace("T"," ");save();audit("test submitted: "+t.title)}
function stClass(){var s=D.students.find(function(x){return x.id==S.child});return s?s.classId:null}
V.tests=function(){
 if(S.role=="parent")return parentTests();
 if(S.role=="student")return studentTests();
 return manageTests()};
function manageTests(){var list=D.tests.filter(function(t){return S.role=="admin"||t.by==S.uname});
 if(TV.m=="q"){var t=myT(TV.id);if(t)return '<h2>Questions: '+esc(t.title)+'</h2><div class="bar"><button data-a="t_back">← Back</button><button class="p" data-a="t_qadd">+ Add question</button></div>'+
  table([["#",function(r){return r.i+1}],["Question",function(r){return esc(r.q.q)}],["Options",function(r){return r.q.o.map(function(x,j){return '<div'+(j==r.q.c?' class="ok"':'')+'>'+"ABCD"[j]+") "+esc(x)+'</div>'}).join("")}]],t.qs.map(function(q,i){return{q:q,i:i}}),function(r){return '<button data-a="t_qedit" data-id="'+r.i+'">Edit</button> <button class="d" data-a="t_qdel" data-id="'+r.i+'">Delete</button>'})+'<p class="mu">The correct option is shown in green (teachers only).</p>';TV.m="list"}
 if(TV.m=="r"){var t=myT(TV.id);if(t){var rows=tsubs(t.id).filter(function(x){return x.end});
  return '<h2>Results: '+esc(t.title)+'</h2><div class="bar"><button data-a="t_back">← Back</button><button class="p" data-a="t_dl" data-k="x">Download Excel</button><button data-a="t_dl" data-k="c">CSV</button></div>'+
  table([["Student",function(r){return esc(stu(r.studentId))}],["Class",function(r){return esc(cls((D.students.find(function(s){return s.id==r.studentId})||{}).classId))}],["Score",function(r){return r.score+" / "+r.total}],["Percent",function(r){return '<span class="'+(pct(r)>=50?"ok":"no")+'">'+pct(r)+'%</span>'}],["Submitted",function(r){return esc(r.end)}]],rows)+'<p class="mu">'+(tsubs(t.id).length-rows.length)+' student(s) started but have not submitted.</p>';TV.m="list"}}
 return '<h2>Online Tests</h2><div class="bar"><button class="p" data-a="t_new">+ Create test</button></div>'+
  table([["Title",function(r){return esc(r.title)}],["Class",function(r){return esc(cls(r.classId))}],["Subject",function(r){return esc(r.subject)}],["Time",function(r){return r.mins+" min"}],["Questions",function(r){return r.qs.length}],["Status",function(r){return r.open?'<span class="ok">Open</span>':'<span class="tag">Closed</span>'}],["Submitted",function(r){return tsubs(r.id).filter(function(x){return x.end}).length}]],list,function(r){
   return '<button data-a="t_q" data-id="'+r.id+'">Questions</button> <button data-a="t_tog" data-id="'+r.id+'">'+(r.open?"Close":"Open")+'</button> <button data-a="t_res" data-id="'+r.id+'">Results</button> <button data-a="t_edit" data-id="'+r.id+'">Edit</button> <button class="d" data-a="t_del" data-id="'+r.id+'">Delete</button>'})+
  '<p class="mu">Create a test, add multiple-choice questions, then press Open so students of that class can take it. Each student has one attempt and the test is graded automatically.</p>'}
function studentTests(){
 var act=D.subs.find(function(x){return x.studentId==S.child&&!x.end});
 if(act){var t=D.tests.find(function(x){return x.id==act.testId});
  if(!t){finalize(act)}else if(Date.now()>=act.start+t.mins*60000){finalize(act);setTimeout(function(){alert("Time is up. Your test was submitted.");render()},0)}
  else{setTimeout(tick,0);return '<h2>'+esc(t.title)+'</h2><div class="bar"><span class="tag">Time left: <b id="tm"></b></span><span class="tag">'+t.qs.length+' questions</span></div>'+
   t.qs.map(function(q,i){return '<div class="card mt8"><b>'+(i+1)+'. '+esc(q.q)+'</b>'+q.o.map(function(o,j){return '<label class="opt"><input type="radio" name="q'+i+'" data-a="t_ans" data-q="'+i+'" data-o="'+j+'"'+(act.ans&&act.ans[i]===j?" checked":"")+'> '+esc(o)+'</label>'}).join("")+'</div>'}).join("")+
   '<p class="mt18"><button class="p" data-a="t_submit">Submit test</button></p><p class="mu">Your answers are saved as you choose them. The test submits automatically when time runs out.</p>'}}
 var cl=stClass(),list=D.tests.filter(function(t){return t.classId==cl&&t.qs.length&&(t.open||D.subs.some(function(x){return x.testId==t.id&&x.studentId==S.child}))});
 return '<h2>Online Tests</h2>'+table([["Test",function(r){return esc(r.title)}],["Subject",function(r){return esc(r.subject)}],["Time",function(r){return r.mins+" min"}],["Questions",function(r){return r.qs.length}],["Result",function(r){var s=D.subs.find(function(x){return x.testId==r.id&&x.studentId==S.child&&x.end});return s?'<span class="'+(pct(s)>=50?"ok":"no")+'">'+s.score+' / '+s.total+' ('+pct(s)+'%)</span>':"—"}]],list,function(r){
  var done=D.subs.some(function(x){return x.testId==r.id&&x.studentId==S.child&&x.end});return done?"":(r.open?'<button class="p" data-a="t_start" data-id="'+r.id+'">Start test</button>':"")})+'<p class="mu">You get one attempt per test. Once you press Start the timer begins.</p>'}
function parentTests(){var rows=D.subs.filter(function(x){return x.end&&mine(x.studentId)});
 return '<h2>Online Test Results</h2>'+table([["Student",function(r){return esc(stu(r.studentId))}],["Test",function(r){var t=D.tests.find(function(x){return x.id==r.testId});return esc(t?t.title:"—")}],["Subject",function(r){var t=D.tests.find(function(x){return x.id==r.testId});return esc(t?t.subject:"")}],["Score",function(r){return r.score+" / "+r.total}],["Percent",function(r){return '<span class="'+(pct(r)>=50?"ok":"no")+'">'+pct(r)+'%</span>'}],["Date",function(r){return esc(r.end)}]],rows.slice().reverse())}
function tick(){if(TK)return;TK=setInterval(function(){var el=$("tm");if(!el||S.role!="student"){clearInterval(TK);TK=null;return}
 var act=D.subs.find(function(x){return x.studentId==S.child&&!x.end}),t=act&&D.tests.find(function(x){return x.id==act.testId});if(!t){clearInterval(TK);TK=null;return}
 var left=Math.max(0,Math.floor((act.start+t.mins*60000-Date.now())/1000));el.textContent=Math.floor(left/60)+":"+("0"+left%60).slice(-2);
 if(left<=0){clearInterval(TK);TK=null;finalize(act);alert("Time is up. Your test was submitted.");render()}},1000)}
function testForm(t){if(!D.classes.length){alert("Add a class first.");return}
 form(t?"Edit test":"Create test",[{k:"title",l:"Test title"},{k:"classId",l:"Class",opts:classOpts()},{k:"subject",l:"Subject"},{k:"mins",l:"Time allowed (minutes)",t:"number"},{k:"open",l:"Status",opts:[[false,"Closed (draft)"],[true,"Open for students"]]}],
  t||{title:"",classId:D.classes[0].id,subject:"",mins:30,open:false},function(o){o.classId=Number(o.classId);o.open=String(o.open)=="true";o.mins=Math.max(1,Math.min(300,Number(o.mins)||30));
   if(t)Object.assign(t,o);else{o.id=nid();o.by=S.uname;o.qs=[];D.tests.push(o);audit("created test "+o.title)}})}
function qForm(t,i){var q=i!=null?t.qs[i]:null;
 form(q?"Edit question":"Add question",[{k:"qt",l:"Question",max:300},{k:"oa",l:"Option A",max:200},{k:"ob",l:"Option B",max:200},{k:"oc",l:"Option C",max:200},{k:"od",l:"Option D",max:200},{k:"ok",l:"Correct answer",opts:[[0,"A"],[1,"B"],[2,"C"],[3,"D"]]}],
  q?{qt:q.q,oa:q.o[0],ob:q.o[1],oc:q.o[2],od:q.o[3],ok:q.c}:{qt:"",oa:"",ob:"",oc:"",od:"",ok:0},function(o){
   var nq={q:o.qt.trim(),o:[o.oa,o.ob,o.oc,o.od].map(function(x){return x.trim()}),c:Number(o.ok)};if(q)t.qs[i]=nq;else t.qs.push(nq)})}
document.addEventListener("click",function(e){var el=e.target,a=el.getAttribute&&el.getAttribute("data-a");if(!a||a.indexOf("t_")!=0||!S.role)return;
 var id=el.getAttribute("data-id"),k=el.getAttribute("data-k"),mg=S.role=="admin"||S.role=="teacher";
 if(mg){
  if(a=="t_new")testForm();
  if(a=="t_edit"){var t=myT(id);if(t)testForm(t)}
  if(a=="t_del"){var t=myT(id);if(t&&confirm("Delete this test and all its results?")){D.tests=D.tests.filter(function(x){return x.id!=t.id});D.subs=D.subs.filter(function(x){return x.testId!=t.id});audit("deleted test "+t.title);save();render()}}
  if(a=="t_tog"){var t=myT(id);if(t){if(!t.open&&!t.qs.length){alert("Add at least one question first.");return}t.open=!t.open;audit((t.open?"opened ":"closed ")+"test "+t.title);save();render()}}
  if(a=="t_q"){if(myT(id)){TV={m:"q",id:Number(id)};render()}}
  if(a=="t_res"){if(myT(id)){TV={m:"r",id:Number(id)};render()}}
  if(a=="t_back"){TV={m:"list",id:null};render()}
  if(a=="t_qadd"){var t=myT(TV.id);if(t)qForm(t)}
  if(a=="t_qedit"){var t=myT(TV.id);if(t)qForm(t,Number(id))}
  if(a=="t_qdel"){var t=myT(TV.id);if(t&&confirm("Delete this question?")){t.qs.splice(Number(id),1);save();render()}}
  if(a=="t_dl"){var t=myT(TV.id);if(t){var h=["EMIS ID","Student","Class","Score","Total","Percent","Submitted"],r=tsubs(t.id).filter(function(x){return x.end}).map(function(x){var s=D.students.find(function(y){return y.id==x.studentId})||{};return[s.emisId||"",s.name||"",cls(s.classId),x.score,x.total,pct(x),x.end]});
   if(k=="x")xl("test-results",h,r);else dl("test-results.csv","\ufeff"+[h].concat(r).map(function(x){return x.map(cell).join(",")}).join("\r\n"),"text/csv")}}
 }
 if(S.role=="student"){
  if(a=="t_start"){var t=D.tests.find(function(x){return x.id==id});
   if(!t||!t.open||t.classId!=stClass()||!t.qs.length)return;
   if(D.subs.some(function(x){return x.studentId==S.child&&x.testId==t.id})){alert("You have already taken this test.");return}
   if(D.subs.some(function(x){return x.studentId==S.child&&!x.end}))return;
   if(!confirm("Start \""+t.title+"\"? You have "+t.mins+" minutes and only one attempt."))return;
   D.subs.push({id:nid(),testId:t.id,studentId:S.child,start:Date.now(),ans:{},end:""});audit("test started: "+t.title);save();render()}
  if(a=="t_ans"){var act=D.subs.find(function(x){return x.studentId==S.child&&!x.end}),t=act&&D.tests.find(function(x){return x.id==act.testId});
   if(act&&t&&Date.now()<act.start+t.mins*60000){act.ans[el.getAttribute("data-q")]=Number(el.getAttribute("data-o"));save()}}
  if(a=="t_submit"){var act=D.subs.find(function(x){return x.studentId==S.child&&!x.end});
   if(act&&confirm("Submit your answers now? You cannot change them afterwards.")){var t=D.tests.find(function(x){return x.id==act.testId});
    var un=t?t.qs.filter(function(q,i){return act.ans[i]===undefined}).length:0;
    if(un&&!confirm(un+" question(s) unanswered. Submit anyway?"))return;
    finalize(act);alert("Submitted. Your score: "+act.score+" / "+act.total+" ("+pct(act)+"%)");render()}}
 }});
async function boot(){await initUsers();loginUI()}
boot();
})();
