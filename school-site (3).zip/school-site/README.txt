SCHOOL MANAGEMENT SYSTEM - WEBSITE WITH YOUR OWN DOMAIN
=========================================================

1) SET YOUR DOMAIN
   Open the file  CNAME  and replace  yourschool.com  with your real domain
   (one line, no http://, no spaces). Example:  burayuacademy.com

2) UPLOAD THE FOLDER (pick one free host)
   Cloudflare Pages:  Workers & Pages > Create > Pages > Upload assets > drop this folder
   Netlify:           app.netlify.com/drop > drop this folder
   GitHub Pages:      push this folder to a repo > Settings > Pages

3) ADD THE DOMAIN IN THE HOST
   Host dashboard > Custom domains > add your domain.
   The host shows DNS records (CNAME or A). Enter them at the place where you bought the domain.
   HTTPS turns on automatically (the login REQUIRES https).
   For Ethio telecom (.et) domains: myportal.ethiotelecom.et > your domain > DNS records.

4) FIRST LOGIN
   admin / Admin#2026   teacher / Teach#2026   parent / Parent#2026
   Each account must choose a new password on first sign-in.

FILES
   index.html, style.css, app.js   the app (keep them in the same folder)
   CNAME                           your domain name
   _headers                        security headers (Netlify / Cloudflare Pages)
   _redirects                      route all addresses to the app
   robots.txt                      asks search engines NOT to list the site
   404.html                        "page not found" page
   .nojekyll                       needed for GitHub Pages

IMPORTANT
   Data is stored in each visitor's own browser, not on a server. Putting the
   site online does not share records between devices, and anyone can read the
   files. For a real shared system, connect the app to a backend and database.

BACKUP & RESTORE (admin)
   Sidebar > SECURITY > Backup & Restore. Download a .json backup of all records,
   password reset requests and the audit log (optionally with user accounts).
   Restore replaces current data and downloads a safety copy first.
   The bell shows a reminder if there has been no backup for 7 days.

ACCOUNTS & ONLINE TESTS
   Admin: User Management > User Accounts. Create Teacher, Parent and Student
   logins. A temporary password is shown once; the user must choose their own at
   first sign-in. "Link child" lets one parent see several children.
   Teacher/Admin: Online Tests > Create test > Questions (multiple choice) > Open.
   Student: logs in, sees open tests for their class, one timed attempt,
   graded automatically. Parent: sees their child's test results.
   Teachers see only their own tests; the admin sees all.
